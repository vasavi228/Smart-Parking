document.addEventListener('DOMContentLoaded', () => {
    const carGrid = document.getElementById('carGrid');
    const selectedCarMessage = document.getElementById('selectedCarMessage');
    const showSelectedButton = document.getElementById('showSelected');
    let selectedCars = [];

    carGrid.addEventListener('click', (e) => {
        if (e.target.classList.contains('car')) {
            if (!e.target.classList.contains('booked')) {
                e.target.classList.toggle('selected');
                const carIndex = e.target.dataset.index;
                if (selectedCars.includes(carIndex)) {
                    selectedCars = selectedCars.filter(index => index !== carIndex);
                } else {
                    selectedCars.push(carIndex);
                }
                updateSelectedCarMessage(carIndex);
            }
        }
    });

    showSelectedButton.addEventListener('click', () => {
        if (selectedCars.length > 0) {
            selectedCarMessage.textContent = `You have selected car numbers: ${selectedCars.join(', ')}`;
        } else {
            selectedCarMessage.textContent = 'No cars selected.';
        }
    });

    function updateSelectedCarMessage(lastSelectedCarIndex) {
        selectedCarMessage.textContent = `You have selected car number ${lastSelectedCarIndex}. Selected cars: ${selectedCars.join(', ')}`;
    }
});
